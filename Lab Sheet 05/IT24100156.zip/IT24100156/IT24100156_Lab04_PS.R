setwd("C:\\Users\\chull\\Desktop\\IT24100156")
getwd()
file.exists("Exercise.txt")
branch_data <- read.csv("Exercise.txt", stringsAsFactors = FALSE)
str(branch_data)
head(branch_data, 6)
expected_cols <- c("Branch", "Sales_X1", "Advertising_X2", "Years_X3")
stopifnot(all(expected_cols %in% names(branch_data)))
sapply(branch_data, class)
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales (X1)",
        ylab  = "Sales_X1")
five_adv <- fivenum(adv)  # Tukey five-number summary
names(five_adv) <- c("Min", "Q1", "Median", "Q3", "Max")
five_adv
iqr_adv <- IQR(adv, na.rm = TRUE)
cat("IQR for Advertising_X2:", iqr_adv, "\n")
mean_adv <- mean(adv, na.rm = TRUE)
sd_adv   <- sd(adv, na.rm = TRUE)
cat("Mean Advertising_X2:", mean_adv, " | SD:", sd_adv, "\n")

find_outliers <- function(x, na.rm = TRUE) {
  q1  <- quantile(x, 0.25, na.rm = na.rm)
  q3  <- quantile(x, 0.75, na.rm = na.rm)
  iqr <- q3 - q1
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  which(x < lower | x > upper)
}

years_idx <- find_outliers(branch_data$Years_X3)

cat("Outliers in Years_X3 (indices):", if (length(years_idx) > 0) years_idx else "None", "\n")

if (length(years_idx) > 0) {
  cat("Outlier values in Years_X3:\n")
  print(branch_data$Years_X3[years_idx])
}


boxplot(branch_data$Years_X3,
        main = "Boxplot of Years (X3)",
        ylab = "Years_X3")


sink("Lab04_key_outputs.txt")
cat("=== STRUCTURE ===\n"); str(branch_data)
cat("\n=== FIVE-NUM (Advertising_X2) ===\n"); print(five_adv)
cat("\n=== IQR (Advertising_X2) ===\n"); print(iqr_adv)
cat("\n=== MEAN/SD (Advertising_X2) ===\n"); print(mean_adv); print(sd_adv)
cat("\n=== OUTLIERS in Years_X3 (indices) ===\n"); print(years_idx)
if (length(years_idx) > 0) {
  cat("\n=== OUTLIER values (Years_X3) ===\n"); print(branch_data$Years_X3[years_idx])
}
sink()
file.exists("Lab04_key_outputs.txt")
